var obj = {
    array1: [{src: './img/image.jpg', x: 250, y: 100, w: 50}, {src: './img/image.jpg', x: 350, y: 100, w: 40}],
    array2: [{src: './img/image.jpg', x: 150, y: 200, w: 40}, {src: './img/image.jpg', x: 150, y: 300, w: 60}]
}
var playground = new Playground(obj);